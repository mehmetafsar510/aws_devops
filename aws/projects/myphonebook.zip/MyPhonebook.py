from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask import Flask, request, flash, url_for, redirect, render_template
from flask_migrate import Migrate
import os


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///contacts.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = os.urandom(32)
db = SQLAlchemy(app)
migrate = Migrate(app, db)

class contacts(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80))
    phone = db.Column(db.String(120))

    def __init__(self, name, phone):
        self.name = name
        self.phone = phone

    def __repr__(self):
        return '<User %r>' % self.name


@app.route("/", methods=["GET", "POST"])
def adder_page():
    errors = ""
    if request.method == "POST":
        number = None             
        try:
            number = int(request.form["number"])
        except:
            errors += " ".format(request.form["number"])

        if number is not None and number == 1:
            number = number
            return redirect(url_for('Display'))                      
        if number is not None and number == 2:
            number = number
            return redirect(url_for('create_contact'))
        elif number is not None and number == 3:
            number=number
            return redirect(url_for('delete')) 
        elif number is not None and 0 >number > 4:
            return render_template ("index.html", errors= number,developer_name = "Mehmet")
        else:
            errors += "Not Valid! Please enter a number 1/ 2/ 3.\n".format(request.form["number"])

    return render_template ("index.html", errors=errors, developer_name = "Mehmet")
  
@app.route('/new', methods=['GET', 'POST'])
def create_contact():
    contact = ""
    if request.method == 'POST':
        if not request.form['name']  or not request.form['phone']:
            flash('Please enter all the fields', 'error')
        elif request.form['name'].isdigit():
            flash("Please enter valid name ")
        elif not request.form['phone'].isdigit():
            flash("Please enter valid phone number!!!!")        
        else:
            contact = contacts(request.form['name'], request.form['phone'])
            db.session.add(contact)
            db.session.commit() 
            flash('Contact was successfully submitted')      
            return redirect(url_for('adder_page'))
    
    return render_template('new.html', valid=True)

@app.route("/delete", methods=['GET', 'POST'])
def delete():
    contact = ""
    if request.method == 'POST':
        name = request.form.get("name")
        phone = request.form['phone']
        if not request.form['name']  or not request.form['phone']:
            flash('Please enter all the fields', 'error')
        elif request.form['name'].isdigit():
            flash("Please enter valid name ")
        elif not request.form['phone'].isdigit():
            flash("Please enter valid phone number!!!!")
        elif  name != contacts.query.filter_by(name=name).first() :
            flash("{!r} is not in the phonebook.\n".format(request.form["name"]))
        else:
            name = request.form.get("name")
            phone = request.form.get("phone")
            contact = contacts.query.filter_by(name=name, phone=phone).delete()
            db.session.commit()
            flash('Contact was successfully deleted')
            return redirect(url_for('adder_page'))
            
    return render_template('new.html', validnot=True)

@app.route("/Display") 
def Display():    
    flash('Contact was successfully displayed')     
    return render_template('display.html',contacts=contacts.query.all())

if __name__ == '__main__':
	
    db.create_all()
    #app.run(debug=True)
    app.run( host="0.0.0.0", port=8080)