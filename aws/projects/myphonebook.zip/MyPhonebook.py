from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask import Flask, request, flash, url_for, redirect, render_template, session
import os


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///contacts.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = os.urandom(32)
db = SQLAlchemy(app)

class contacts(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80))
    phone = db.Column(db.String(120))

    def __init__(self, name, phone):
        self.name = name
        self.phone = phone

    def __repr__(self):
        return '<User %r>' % self.name


@app.route("/", methods=["GET", "POST"])
def adder_page():
    errors = ""
    if request.method == "POST":
        number = None             
        try:
            number = int(request.form["number"])
        except:
            errors += " ".format(request.form["number"])
        if number is not None and number == 1:
            return redirect(url_for('Display'))                      
        if number is not None and number == 2:
            return redirect(url_for('create_contact'))
        elif number is not None and number == 3:
            return redirect(url_for('delete'))
        elif number is not None and number == 4:
            return redirect(url_for('terminate'))
        elif number is not None and number == 5:
            return redirect(url_for('allname'))
        elif number is not None and 0 >number > 6:
            return render_template ("index.html", errors= number,developer_name = "Mehmet")
        else:
            errors += "Not Valid! Please enter a number 1/ 2/ 3.\n".format(request.form["number"])

    return render_template ("index.html", errors=errors, developer_name = "Mehmet")
  
@app.route('/new', methods=['GET', 'POST'])
def create_contact():
    contact = ""
    if request.method == 'POST':
        if not request.form['name']  or not request.form['phone']:
            flash('Please enter all the fields', 'error')
        elif request.form['name'].isdigit():
            flash("Please enter valid name ")
        elif not request.form['phone'].isdigit():
            flash("Please enter valid phone number!!!!")        
        else:
            contact = contacts(request.form['name'], request.form['phone'])
            db.session.add(contact)
            db.session.commit() 
            flash('Contact was successfully added')      
            return redirect(url_for('adder_page'))
    
    return render_template('new.html', valid=True)

@app.route("/delete", methods=['GET', 'POST'])
def delete():
    contact = ""
    if request.method == 'POST':
        name = request.form.get("name")
        phone = request.form.get("phone")
        user = contacts.query.filter_by(name=name).first()
        if not request.form['name'] :
            flash('Please enter  the fields', 'error')
        elif request.form['name'].isdigit():
            flash("Please enter valid name ")
        elif  not user:
            flash("{!r} is not in the phonebook.\n".format(request.form["name"]))
        else:
            name = request.form.get("name")
            contact = contacts.query.filter_by(name=name).delete()
            db.session.commit()
            flash('Contact was successfully deleted')
            return redirect(url_for('adder_page'))
            
    return render_template('new1.html', validnot=True)

@app.route("/Display", methods=['GET', 'POST'] ) 
def Display():
    if request.method == "POST":
        name = request.form["name"]
        user = contacts.query.filter_by(name=name).first()
        if not request.form['name'] :
           flash('Please enter  the fields', 'error')
        elif request.form['name'].isdigit():
            flash("Please enter valid name ")
        elif  not user:
            flash(" Couldn't find phone number of {!r} \n".format(request.form["name"]))
        else:
            flash('Contact was successfully displayed')     
            return render_template('display.html', contacts=contacts.query.filter_by(name=name))
    return render_template('new1.html', valid=True)

@app.route('/terminate')
def terminate():
    return render_template('terminate.html', validnot=True)
    
@app.route("/allname")
def allname():
    return render_template('display.html', contacts=contacts.query.all())

if __name__ == '__main__':
	
    db.create_all()
    #app.run(debug=True)
    app.run( host="0.0.0.0", port=80)