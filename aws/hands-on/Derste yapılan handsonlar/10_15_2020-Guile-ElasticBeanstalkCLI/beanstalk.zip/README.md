eb-python-flask
===============
Simple Python and Flask sample application from [AWS Elastic Beanstalk Developer Guide](http://docs.aws.amazon.com/elasticbeanstalk/latest/dg/create_deploy_Python_flask.html)

Note: this application asks you to authenticate. For testing, the logins and
passwords are hard-coded.  They are:

 - User 1: login: joe; Password: password123
 - User 2: login: anne Password: password123
