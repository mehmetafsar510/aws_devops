# Ideas
This file contains ideas for future additions and enhancements to this application.

* Types of days ideas:
	* Day off
	* Half days
	* Travel days
	* Conference days
	* Overtime days
	* Holidays (company issued vs personal choice)
	* Maternity/Paternity leave days
	* Personal leave days
	* Training days
	* Medical leave days
	* Jury duty days
	* Other

* Time Card Capability

* Analytics/Logging data

* Database credentials/Auth

* Persistant data for database in Docker container

* Create Admin User

* View other user's calendar data with permission

* More funcionality/analytics with graphs/charts

* Allow for no resetting of database when database schema changes