#!/bin/bash


echo "Creating the volume..."

kubectl apply -f ./kubernetes/persistent_volume.yaml
kubectl apply -f ./kubernetes/persistent_volume_claim.yaml


echo "Creating the database credentials..."

kubectl apply -f ./kubernetes/mysql_secret.yaml

echo "Creating the database configmap credentials..."

kubectl apply -f ./kubernetes/database_configmap.yaml


echo "Creating the mysql deployment and service..."

kubectl create -f ./kubernetes/mysql_deployement.yaml
kubectl create -f ./kubernetes/mysql_service.yaml

echo "Creating the service configmap credentials..."

kubectl apply -f ./kubernetes/servers_configmap.yaml


echo "Creating the web_server deployment and service..."

kubectl create -f ./kubernetes/web_server_deployement.yaml
kubectl create -f ./kubernetes/web_server_service.yaml
