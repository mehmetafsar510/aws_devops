#!/bin/bash


echo "Creating the volume..."

kubectl apply -f ./kubernetes/persistent-volume.yml
kubectl apply -f ./kubernetes/persistent-volume-claim.yml


echo "Creating the database credentials..."

kubectl apply -f ./kubernetes/mysql-secret.yaml


echo "Creating the mysql deployment and service..."

kubectl create -f ./kubernetes/mysql-deployment-service.yml

echo "Creating the database configmap credentials..."

kubectl apply -f ./kubernetes/database_configmap.yaml

echo "Creating the Dockerfile credentials..."

sudo docker build -t mehmetafsar510/phonebook-api ./kubernetes

echo "Creating the flask deployment and service..."

kubectl create -f ./kubernetes/flask-deployment.yml
kubectl create -f ./kubernetes/flask-service.yml
